-- =============================================================================
-- PROJECT MANAGEMENT DATABASE - COMPLETE SETUP SCRIPT
-- Description : Idempotent script to create DB, user, schema, tables, and data
-- Author      : Generated via AI Prompt
-- Compatible  : PostgreSQL 13+
-- Usage       : Run as a superuser → psql -U postgres -f setup_project_db.sql
-- =============================================================================


-- =============================================================================
-- SECTION 1: DATABASE CREATION
-- =============================================================================

-- Create the database if it doesn't already exist (idempotent via DO block)
DO
$$
BEGIN
   IF NOT EXISTS (
      SELECT FROM pg_database WHERE datname = 'project_mgmt_db'
   ) THEN
      PERFORM dblink_exec(
         'dbname=' || current_database(),
         'CREATE DATABASE project_mgmt_db
            WITH
            OWNER     = postgres
            ENCODING  = ''UTF8''
            LC_COLLATE = ''en_US.UTF-8''
            LC_CTYPE   = ''en_US.UTF-8''
            TEMPLATE  = template0
            CONNECTION LIMIT = -1;'
      );
      RAISE NOTICE 'Database project_mgmt_db created.';
   ELSE
      RAISE NOTICE 'Database project_mgmt_db already exists — skipping creation.';
   END IF;
END
$$;


-- =============================================================================
-- SECTION 2: USER / ROLE CREATION
-- =============================================================================

-- Create application user if not already present
DO
$$
BEGIN
   IF NOT EXISTS (
      SELECT FROM pg_roles WHERE rolname = 'proj_app_user'
   ) THEN
      CREATE ROLE proj_app_user WITH
         LOGIN
         PASSWORD 'StrongP@ssw0rd!2025'
         NOSUPERUSER
         NOCREATEDB
         NOCREATEROLE
         CONNECTION LIMIT 20;
      RAISE NOTICE 'Role proj_app_user created.';
   ELSE
      RAISE NOTICE 'Role proj_app_user already exists — skipping creation.';
   END IF;
END
$$;

-- Create a read-only reporting user
DO
$$
BEGIN
   IF NOT EXISTS (
      SELECT FROM pg_roles WHERE rolname = 'proj_readonly_user'
   ) THEN
      CREATE ROLE proj_readonly_user WITH
         LOGIN
         PASSWORD 'R3adOnly@2025!'
         NOSUPERUSER
         NOCREATEDB
         NOCREATEROLE;
      RAISE NOTICE 'Role proj_readonly_user created.';
   ELSE
      RAISE NOTICE 'Role proj_readonly_user already exists — skipping creation.';
   END IF;
END
$$;

-- Grant privileges on the database
GRANT ALL PRIVILEGES ON DATABASE project_mgmt_db TO proj_app_user;
GRANT CONNECT ON DATABASE project_mgmt_db TO proj_readonly_user;


-- =============================================================================
-- SECTION 3: CONNECT TO THE TARGET DATABASE
-- All subsequent commands execute inside project_mgmt_db
-- =============================================================================

\c project_mgmt_db


-- =============================================================================
-- SECTION 4: EXTENSION SETUP
-- =============================================================================

-- Enable UUID generation (idempotent — IF NOT EXISTS)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable pg_trgm for fast text search
CREATE EXTENSION IF NOT EXISTS "pg_trgm";


-- =============================================================================
-- SECTION 5: SCHEMA
-- =============================================================================

-- Use a dedicated schema to separate app objects from public
CREATE SCHEMA IF NOT EXISTS pm;

-- Set default search path for this session
SET search_path TO pm, public;

-- Grant schema usage to the application and readonly users
GRANT USAGE ON SCHEMA pm TO proj_app_user, proj_readonly_user;
GRANT ALL   ON ALL TABLES IN SCHEMA pm TO proj_app_user;
GRANT SELECT ON ALL TABLES IN SCHEMA pm TO proj_readonly_user;

-- Ensure future tables automatically inherit the same grants
ALTER DEFAULT PRIVILEGES IN SCHEMA pm
   GRANT ALL    ON TABLES TO proj_app_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA pm
   GRANT SELECT ON TABLES TO proj_readonly_user;


-- =============================================================================
-- SECTION 6: TABLE DEFINITIONS
-- =============================================================================

-- ----------------------------------------------------------------------------
-- 6.1  organisations
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.organisations (
   organisation_id   UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   name              VARCHAR(200)  NOT NULL UNIQUE,
   industry          VARCHAR(100),
   country           CHAR(2)       NOT NULL DEFAULT 'AU',
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   is_active         BOOLEAN       NOT NULL DEFAULT TRUE
);

COMMENT ON TABLE  pm.organisations                IS 'Top-level tenant / client organisations.';
COMMENT ON COLUMN pm.organisations.country        IS 'ISO 3166-1 alpha-2 country code.';

-- ----------------------------------------------------------------------------
-- 6.2  users
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.users (
   user_id           UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   organisation_id   UUID          NOT NULL REFERENCES pm.organisations(organisation_id) ON DELETE CASCADE,
   email             VARCHAR(320)  NOT NULL UNIQUE,
   full_name         VARCHAR(200)  NOT NULL,
   role              VARCHAR(50)   NOT NULL CHECK (role IN ('admin','manager','developer','tester','viewer')),
   password_hash     TEXT          NOT NULL,
   last_login_at     TIMESTAMPTZ,
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   is_active         BOOLEAN       NOT NULL DEFAULT TRUE
);

COMMENT ON TABLE  pm.users          IS 'Application users, scoped to an organisation.';
COMMENT ON COLUMN pm.users.role     IS 'Role controls what the user can see and do.';

-- ----------------------------------------------------------------------------
-- 6.3  projects
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.projects (
   project_id        UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   organisation_id   UUID          NOT NULL REFERENCES pm.organisations(organisation_id) ON DELETE CASCADE,
   owner_id          UUID          NOT NULL REFERENCES pm.users(user_id),
   name              VARCHAR(200)  NOT NULL,
   description       TEXT,
   status            VARCHAR(30)   NOT NULL DEFAULT 'planning'
                        CHECK (status IN ('planning','active','on_hold','completed','cancelled')),
   priority          SMALLINT      NOT NULL DEFAULT 3
                        CHECK (priority BETWEEN 1 AND 5),   -- 1 = highest
   start_date        DATE,
   end_date          DATE,
   budget            NUMERIC(14,2),
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   CONSTRAINT chk_project_dates CHECK (end_date IS NULL OR end_date >= start_date)
);

COMMENT ON TABLE  pm.projects          IS 'Projects belong to one organisation and have a designated owner.';
COMMENT ON COLUMN pm.projects.priority IS '1 = critical, 5 = low priority.';

-- ----------------------------------------------------------------------------
-- 6.4  milestones
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.milestones (
   milestone_id      UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   project_id        UUID          NOT NULL REFERENCES pm.projects(project_id) ON DELETE CASCADE,
   name              VARCHAR(200)  NOT NULL,
   due_date          DATE          NOT NULL,
   is_completed      BOOLEAN       NOT NULL DEFAULT FALSE,
   completed_at      TIMESTAMPTZ,
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6.5  tasks
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.tasks (
   task_id           UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   project_id        UUID          NOT NULL REFERENCES pm.projects(project_id) ON DELETE CASCADE,
   milestone_id      UUID          REFERENCES pm.milestones(milestone_id) ON DELETE SET NULL,
   assignee_id       UUID          REFERENCES pm.users(user_id) ON DELETE SET NULL,
   created_by_id     UUID          NOT NULL REFERENCES pm.users(user_id),
   title             VARCHAR(300)  NOT NULL,
   description       TEXT,
   status            VARCHAR(30)   NOT NULL DEFAULT 'backlog'
                        CHECK (status IN ('backlog','in_progress','in_review','done','cancelled')),
   priority          SMALLINT      NOT NULL DEFAULT 3
                        CHECK (priority BETWEEN 1 AND 5),
   story_points      SMALLINT      CHECK (story_points > 0),
   due_date          DATE,
   completed_at      TIMESTAMPTZ,
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE pm.tasks IS 'Atomic work items within a project, optionally linked to a milestone.';

-- ----------------------------------------------------------------------------
-- 6.6  task_comments
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.task_comments (
   comment_id        UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   task_id           UUID          NOT NULL REFERENCES pm.tasks(task_id) ON DELETE CASCADE,
   author_id         UUID          NOT NULL REFERENCES pm.users(user_id),
   body              TEXT          NOT NULL,
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6.7  tags  (many-to-many via task_tags)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.tags (
   tag_id     UUID         DEFAULT uuid_generate_v4() PRIMARY KEY,
   name       VARCHAR(60)  NOT NULL UNIQUE,
   colour     CHAR(7)      DEFAULT '#607D8B'   -- hex colour for UI badges
);

CREATE TABLE IF NOT EXISTS pm.task_tags (
   task_id   UUID NOT NULL REFERENCES pm.tasks(task_id) ON DELETE CASCADE,
   tag_id    UUID NOT NULL REFERENCES pm.tags(tag_id)   ON DELETE CASCADE,
   PRIMARY KEY (task_id, tag_id)
);

-- ----------------------------------------------------------------------------
-- 6.8  audit_log  (append-only change history)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm.audit_log (
   log_id        BIGSERIAL     PRIMARY KEY,
   table_name    VARCHAR(100)  NOT NULL,
   record_id     UUID          NOT NULL,
   action        CHAR(1)       NOT NULL CHECK (action IN ('I','U','D')),
   changed_by    UUID,
   changed_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   old_data      JSONB,
   new_data      JSONB
);

COMMENT ON TABLE  pm.audit_log          IS 'Immutable audit trail for key table mutations.';
COMMENT ON COLUMN pm.audit_log.action   IS 'I = INSERT, U = UPDATE, D = DELETE.';


-- =============================================================================
-- SECTION 7: INDEXES
-- =============================================================================

-- users
CREATE INDEX IF NOT EXISTS idx_users_org           ON pm.users(organisation_id);
CREATE INDEX IF NOT EXISTS idx_users_email_trgm    ON pm.users USING gin(email gin_trgm_ops);

-- projects
CREATE INDEX IF NOT EXISTS idx_projects_org        ON pm.projects(organisation_id);
CREATE INDEX IF NOT EXISTS idx_projects_owner      ON pm.projects(owner_id);
CREATE INDEX IF NOT EXISTS idx_projects_status     ON pm.projects(status);

-- tasks
CREATE INDEX IF NOT EXISTS idx_tasks_project       ON pm.tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee      ON pm.tasks(assignee_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status        ON pm.tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date      ON pm.tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_title_trgm    ON pm.tasks USING gin(title gin_trgm_ops);

-- audit_log
CREATE INDEX IF NOT EXISTS idx_audit_table_record  ON pm.audit_log(table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_audit_changed_at    ON pm.audit_log(changed_at DESC);


-- =============================================================================
-- SECTION 8: TRIGGER — auto-update updated_at
-- =============================================================================

CREATE OR REPLACE FUNCTION pm.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql AS
$$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$;

-- Apply the trigger to every table that has an updated_at column (idempotent drop+create)
DO
$$
DECLARE
   tbl TEXT;
BEGIN
   FOREACH tbl IN ARRAY ARRAY['users','projects','tasks','task_comments']
   LOOP
      EXECUTE format(
         'DROP TRIGGER IF EXISTS trg_set_updated_at ON pm.%I;
          CREATE TRIGGER trg_set_updated_at
            BEFORE UPDATE ON pm.%I
            FOR EACH ROW EXECUTE FUNCTION pm.set_updated_at();',
         tbl, tbl
      );
   END LOOP;
END;
$$;


-- =============================================================================
-- SECTION 9: SEED DATA  (idempotent — INSERT … ON CONFLICT DO NOTHING)
-- =============================================================================

-- ── 9.1  Organisations ───────────────────────────────────────────────────────
INSERT INTO pm.organisations (organisation_id, name, industry, country) VALUES
   ('a1000000-0000-0000-0000-000000000001', 'Nexus Defence Consulting', 'Defence',         'AU'),
   ('a1000000-0000-0000-0000-000000000002', 'SkyBridge Technologies',   'Information Tech','AU'),
   ('a1000000-0000-0000-0000-000000000003', 'HealthCore Systems',       'Healthcare',      'AU')
ON CONFLICT (organisation_id) DO NOTHING;

-- ── 9.2  Users ───────────────────────────────────────────────────────────────
-- NOTE: password_hash values shown here are bcrypt placeholders.
--       Replace with properly hashed values in production.
INSERT INTO pm.users (user_id, organisation_id, email, full_name, role, password_hash) VALUES
   ('b1000000-0000-0000-0000-000000000001',
    'a1000000-0000-0000-0000-000000000001',
    'alice.chen@nexusdefence.com.au', 'Alice Chen', 'admin',
    '$2b$12$PLACEHOLDER_HASH_ADMIN_ALICE'),

   ('b1000000-0000-0000-0000-000000000002',
    'a1000000-0000-0000-0000-000000000001',
    'bob.nguyen@nexusdefence.com.au', 'Bob Nguyen', 'manager',
    '$2b$12$PLACEHOLDER_HASH_MGR_BOB'),

   ('b1000000-0000-0000-0000-000000000003',
    'a1000000-0000-0000-0000-000000000001',
    'sara.smith@nexusdefence.com.au', 'Sara Smith', 'tester',
    '$2b$12$PLACEHOLDER_HASH_TESTER_SARA'),

   ('b1000000-0000-0000-0000-000000000004',
    'a1000000-0000-0000-0000-000000000002',
    'james.ward@skybridge.com.au',   'James Ward', 'developer',
    '$2b$12$PLACEHOLDER_HASH_DEV_JAMES'),

   ('b1000000-0000-0000-0000-000000000005',
    'a1000000-0000-0000-0000-000000000002',
    'priya.ram@skybridge.com.au',    'Priya Ramanujan', 'manager',
    '$2b$12$PLACEHOLDER_HASH_MGR_PRIYA')
ON CONFLICT (user_id) DO NOTHING;

-- ── 9.3  Projects ────────────────────────────────────────────────────────────
INSERT INTO pm.projects
   (project_id, organisation_id, owner_id, name, description,
    status, priority, start_date, end_date, budget)
VALUES
   ('c1000000-0000-0000-0000-000000000001',
    'a1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000002',
    'COSPO OT&E Automation Suite',
    'Operational Test and Evaluation framework for COSPO CYB9131 programme.',
    'active', 1, '2025-01-15', '2025-12-31', 480000.00),

   ('c1000000-0000-0000-0000-000000000002',
    'a1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000002',
    'One Defence Data — Tranche 2',
    'Continuation of 1DD data migration and integration testing for Tranche 2.',
    'planning', 2, '2025-07-01', '2026-06-30', 920000.00),

   ('c1000000-0000-0000-0000-000000000003',
    'a1000000-0000-0000-0000-000000000002',
    'b1000000-0000-0000-0000-000000000005',
    'Cloud Infrastructure Migration',
    'Lift-and-shift of on-premises workloads to Azure with Terraform IaC.',
    'active', 2, '2025-03-01', '2025-10-31', 310000.00)
ON CONFLICT (project_id) DO NOTHING;

-- ── 9.4  Milestones ──────────────────────────────────────────────────────────
INSERT INTO pm.milestones (milestone_id, project_id, name, due_date, is_completed) VALUES
   ('d1000000-0000-0000-0000-000000000001',
    'c1000000-0000-0000-0000-000000000001',
    'Test Environment Provisioned', '2025-03-31', TRUE),

   ('d1000000-0000-0000-0000-000000000002',
    'c1000000-0000-0000-0000-000000000001',
    'VCRM v1.0 Baselined',          '2025-06-30', FALSE),

   ('d1000000-0000-0000-0000-000000000003',
    'c1000000-0000-0000-0000-000000000003',
    'Azure Landing Zone Deployed',  '2025-05-31', FALSE)
ON CONFLICT (milestone_id) DO NOTHING;

-- ── 9.5  Tasks ───────────────────────────────────────────────────────────────
INSERT INTO pm.tasks
   (task_id, project_id, milestone_id, assignee_id, created_by_id,
    title, description, status, priority, story_points, due_date)
VALUES
   ('e1000000-0000-0000-0000-000000000001',
    'c1000000-0000-0000-0000-000000000001',
    'd1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000002',
    'Draft Test and Evaluation Master Plan (TEMP)',
    'Produce initial TEMP covering scope, objectives, resources, and schedule.',
    'in_progress', 1, 13, '2025-04-30'),

   ('e1000000-0000-0000-0000-000000000002',
    'c1000000-0000-0000-0000-000000000001',
    'd1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000002',
    'Configure Azure DevOps CI/CD Pipeline for Test Automation',
    'Set up pipelines using YAML templates; integrate Selenium WebDriver suite.',
    'backlog', 2, 8, '2025-05-15'),

   ('e1000000-0000-0000-0000-000000000003',
    'c1000000-0000-0000-0000-000000000001',
    'd1000000-0000-0000-0000-000000000002',
    'b1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000002',
    'Build Verification Cross Reference Matrix (VCRM)',
    'Map system requirements to test cases; baseline for AT&E phase.',
    'backlog', 1, 21, '2025-06-15'),

   ('e1000000-0000-0000-0000-000000000004',
    'c1000000-0000-0000-0000-000000000003',
    'd1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000004',
    'b1000000-0000-0000-0000-000000000005',
    'Author Terraform Modules for Azure Landing Zone',
    'Modules for VNet, NSG, Key Vault, Storage Account with Terraform 1.7.',
    'in_progress', 2, 13, '2025-05-10'),

   ('e1000000-0000-0000-0000-000000000005',
    'c1000000-0000-0000-0000-000000000003',
    'd1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000004',
    'b1000000-0000-0000-0000-000000000005',
    'Implement Ansible Playbooks for OS Hardening',
    'CIS Level 2 baseline applied via Ansible roles on all Azure VMs.',
    'backlog', 2, 8, '2025-05-25')
ON CONFLICT (task_id) DO NOTHING;

-- ── 9.6  Tags ────────────────────────────────────────────────────────────────
INSERT INTO pm.tags (tag_id, name, colour) VALUES
   ('f1000000-0000-0000-0000-000000000001', 'security',      '#F44336'),
   ('f1000000-0000-0000-0000-000000000002', 'automation',    '#2196F3'),
   ('f1000000-0000-0000-0000-000000000003', 'documentation', '#FF9800'),
   ('f1000000-0000-0000-0000-000000000004', 'infrastructure','#4CAF50'),
   ('f1000000-0000-0000-0000-000000000005', 'testing',       '#9C27B0')
ON CONFLICT (tag_id) DO NOTHING;

-- ── 9.7  Task ↔ Tag links ────────────────────────────────────────────────────
INSERT INTO pm.task_tags (task_id, tag_id) VALUES
   ('e1000000-0000-0000-0000-000000000001','f1000000-0000-0000-0000-000000000003'), -- TEMP → documentation
   ('e1000000-0000-0000-0000-000000000001','f1000000-0000-0000-0000-000000000005'), -- TEMP → testing
   ('e1000000-0000-0000-0000-000000000002','f1000000-0000-0000-0000-000000000002'), -- CI/CD → automation
   ('e1000000-0000-0000-0000-000000000002','f1000000-0000-0000-0000-000000000005'), -- CI/CD → testing
   ('e1000000-0000-0000-0000-000000000003','f1000000-0000-0000-0000-000000000003'), -- VCRM → documentation
   ('e1000000-0000-0000-0000-000000000003','f1000000-0000-0000-0000-000000000005'), -- VCRM → testing
   ('e1000000-0000-0000-0000-000000000004','f1000000-0000-0000-0000-000000000004'), -- Terraform → infrastructure
   ('e1000000-0000-0000-0000-000000000005','f1000000-0000-0000-0000-000000000001'), -- Ansible → security
   ('e1000000-0000-0000-0000-000000000005','f1000000-0000-0000-0000-000000000004')  -- Ansible → infrastructure
ON CONFLICT DO NOTHING;

-- ── 9.8  Task Comments ───────────────────────────────────────────────────────
INSERT INTO pm.task_comments (task_id, author_id, body) VALUES
   ('e1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000002',
    'Prioritise Section 4 (Test Resources) first — resource confirmation is on the critical path.'),

   ('e1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000003',
    'Initial draft ready for review. Shared in the SharePoint folder under /COSPO/TEMP/v0.1.'),

   ('e1000000-0000-0000-0000-000000000004',
    'b1000000-0000-0000-0000-000000000004',
    'Hub-spoke topology confirmed with network team. Will push first module PR by Friday.')
ON CONFLICT DO NOTHING;


-- =============================================================================
-- SECTION 10: USEFUL VERIFICATION QUERIES
-- =============================================================================

-- Quick row counts to confirm seeding
SELECT 'organisations' AS table_name, COUNT(*) AS rows FROM pm.organisations
UNION ALL SELECT 'users',         COUNT(*) FROM pm.users
UNION ALL SELECT 'projects',      COUNT(*) FROM pm.projects
UNION ALL SELECT 'milestones',    COUNT(*) FROM pm.milestones
UNION ALL SELECT 'tasks',         COUNT(*) FROM pm.tasks
UNION ALL SELECT 'tags',          COUNT(*) FROM pm.tags
UNION ALL SELECT 'task_tags',     COUNT(*) FROM pm.task_tags
UNION ALL SELECT 'task_comments', COUNT(*) FROM pm.task_comments
ORDER BY table_name;

-- Active tasks with project and assignee details
SELECT
   p.name                          AS project,
   t.title                         AS task,
   t.status,
   t.priority,
   u.full_name                     AS assignee,
   t.due_date,
   STRING_AGG(tg.name, ', ')       AS tags
FROM pm.tasks        t
JOIN pm.projects     p  ON p.project_id  = t.project_id
LEFT JOIN pm.users   u  ON u.user_id     = t.assignee_id
LEFT JOIN pm.task_tags  tt ON tt.task_id = t.task_id
LEFT JOIN pm.tags    tg ON tg.tag_id     = tt.tag_id
WHERE t.status NOT IN ('done','cancelled')
GROUP BY p.name, t.title, t.status, t.priority, u.full_name, t.due_date
ORDER BY t.priority, t.due_date;

-- =============================================================================
-- END OF SCRIPT
-- =============================================================================
