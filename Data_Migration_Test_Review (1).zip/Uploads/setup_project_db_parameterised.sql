-- =============================================================================
-- PROJECT MANAGEMENT DATABASE - PARAMETERISED SETUP SCRIPT
-- Description : Idempotent script — all names defined once in Section 0 below.
-- Compatible  : PostgreSQL 13+  |  psql client required (uses \set and \c)
-- Usage       : psql -U postgres -f setup_project_db_parameterised.sql
--
-- HOW VARIABLES WORK IN THIS SCRIPT
--   \set varname  value          → defines a variable
--   :'varname'                   → substituted as a quoted STRING LITERAL
--   :"varname"                   → substituted as a quoted IDENTIFIER
--   Works inside DO $$ $$ blocks, DDL, DML, and psql meta-commands (\c etc.)
-- =============================================================================


-- =============================================================================
-- SECTION 0: ★ CENTRALISED CONFIGURATION — EDIT ONLY HERE ★
-- =============================================================================

-- ── Database ─────────────────────────────────────────────────────────────────
\set db_name            project_mgmt_db
\set db_owner           postgres

-- ── Schema ───────────────────────────────────────────────────────────────────
\set schema_name        pm

-- ── Users / Roles ────────────────────────────────────────────────────────────
\set app_user           proj_app_user
\set app_password       StrongP@ssw0rd!2025
\set readonly_user      proj_readonly_user
\set readonly_password  R3adOnly@2025!

-- ── Table Names ──────────────────────────────────────────────────────────────
\set tbl_organisations  organisations
\set tbl_users          users
\set tbl_projects       projects
\set tbl_milestones     milestones
\set tbl_tasks          tasks
\set tbl_task_comments  task_comments
\set tbl_tags           tags
\set tbl_task_tags      task_tags
\set tbl_audit_log      audit_log

-- ── Trigger Function Name ─────────────────────────────────────────────────────
\set fn_updated_at      set_updated_at

-- =============================================================================
-- END OF CONFIGURATION — Do not edit below this line unless changing logic
-- =============================================================================




-- =============================================================================
-- SECTION 1: DATABASE CREATION
-- =============================================================================

\echo '>> [1/10] Creating database:' :db_name

DO
$$
BEGIN
   IF NOT EXISTS (
      SELECT FROM pg_database WHERE datname = :'db_name'
   ) THEN
      PERFORM dblink_exec(
         'dbname=' || current_database(),
         'CREATE DATABASE "' || :'db_name' || '"
            WITH
            OWNER     = "' || :'db_owner' || '"
            ENCODING  = ''UTF8''
            TEMPLATE  = template0
            CONNECTION LIMIT = -1'
      );
      RAISE NOTICE 'Database "%" created.', :'db_name';
   ELSE
      RAISE NOTICE 'Database "%" already exists — skipping.', :'db_name';
   END IF;
END
$$;


-- =============================================================================
-- SECTION 2: USER / ROLE CREATION
-- =============================================================================

\echo '>> [2/10] Creating roles:' :app_user 'and' :readonly_user

-- Application user (read/write)
DO
$$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'app_user') THEN
      EXECUTE format(
         'CREATE ROLE %I WITH LOGIN PASSWORD %L
          NOSUPERUSER NOCREATEDB NOCREATEROLE CONNECTION LIMIT 20',
         :'app_user', :'app_password'
      );
      RAISE NOTICE 'Role "%" created.', :'app_user';
   ELSE
      RAISE NOTICE 'Role "%" already exists — skipping.', :'app_user';
   END IF;
END
$$;

-- Read-only reporting user
DO
$$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'readonly_user') THEN
      EXECUTE format(
         'CREATE ROLE %I WITH LOGIN PASSWORD %L
          NOSUPERUSER NOCREATEDB NOCREATEROLE',
         :'readonly_user', :'readonly_password'
      );
      RAISE NOTICE 'Role "%" created.', :'readonly_user';
   ELSE
      RAISE NOTICE 'Role "%" already exists — skipping.', :'readonly_user';
   END IF;
END
$$;

-- Grant database-level privileges
EXECUTE format('GRANT ALL PRIVILEGES ON DATABASE %I TO %I', :'db_name', :'app_user');
EXECUTE format('GRANT CONNECT         ON DATABASE %I TO %I', :'db_name', :'readonly_user');


-- =============================================================================
-- SECTION 3: CONNECT TO THE TARGET DATABASE
-- =============================================================================

\echo '>> [3/10] Connecting to database:' :db_name

\c :"db_name"


-- =============================================================================
-- SECTION 4: EXTENSIONS
-- =============================================================================

\echo '>> [4/10] Enabling extensions'

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";   -- uuid_generate_v4()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";     -- GIN trigram indexes
CREATE EXTENSION IF NOT EXISTS "dblink";      -- used in Section 1 above


-- =============================================================================
-- SECTION 5: SCHEMA
-- =============================================================================

\echo '>> [5/10] Creating schema:' :schema_name

CREATE SCHEMA IF NOT EXISTS :"schema_name";

-- Set the search path for the remainder of this session
SELECT set_config('search_path', :'schema_name' || ',public', false);

-- Grant schema access
EXECUTE format('GRANT USAGE  ON SCHEMA %I TO %I, %I',
               :'schema_name', :'app_user', :'readonly_user');
EXECUTE format('GRANT ALL    ON ALL TABLES IN SCHEMA %I TO %I',
               :'schema_name', :'app_user');
EXECUTE format('GRANT SELECT ON ALL TABLES IN SCHEMA %I TO %I',
               :'schema_name', :'readonly_user');

-- Future tables inherit the same grants automatically
EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I
                GRANT ALL    ON TABLES TO %I', :'schema_name', :'app_user');
EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA %I
                GRANT SELECT ON TABLES TO %I', :'schema_name', :'readonly_user');


-- =============================================================================
-- SECTION 6: TABLE DEFINITIONS
-- All tables are schema-qualified using :"schema_name"."tbl_*" variables.
-- =============================================================================

\echo '>> [6/10] Creating tables'

-- ----------------------------------------------------------------------------
-- 6.1  organisations
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_organisations" (
   organisation_id   UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   name              VARCHAR(200)  NOT NULL UNIQUE,
   industry          VARCHAR(100),
   country           CHAR(2)       NOT NULL DEFAULT 'AU',
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   is_active         BOOLEAN       NOT NULL DEFAULT TRUE
);

COMMENT ON TABLE  :"schema_name".:"tbl_organisations"
   IS 'Top-level tenant / client organisations.';
COMMENT ON COLUMN :"schema_name".:"tbl_organisations".country
   IS 'ISO 3166-1 alpha-2 country code.';

-- ----------------------------------------------------------------------------
-- 6.2  users
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_users" (
   user_id           UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   organisation_id   UUID          NOT NULL
      REFERENCES :"schema_name".:"tbl_organisations"(organisation_id) ON DELETE CASCADE,
   email             VARCHAR(320)  NOT NULL UNIQUE,
   full_name         VARCHAR(200)  NOT NULL,
   role              VARCHAR(50)   NOT NULL
      CHECK (role IN ('admin','manager','developer','tester','viewer')),
   password_hash     TEXT          NOT NULL,
   last_login_at     TIMESTAMPTZ,
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   is_active         BOOLEAN       NOT NULL DEFAULT TRUE
);

COMMENT ON TABLE  :"schema_name".:"tbl_users"
   IS 'Application users, scoped to an organisation.';
COMMENT ON COLUMN :"schema_name".:"tbl_users".role
   IS 'Controls what the user can see and do.';

-- ----------------------------------------------------------------------------
-- 6.3  projects
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_projects" (
   project_id        UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   organisation_id   UUID          NOT NULL
      REFERENCES :"schema_name".:"tbl_organisations"(organisation_id) ON DELETE CASCADE,
   owner_id          UUID          NOT NULL
      REFERENCES :"schema_name".:"tbl_users"(user_id),
   name              VARCHAR(200)  NOT NULL,
   description       TEXT,
   status            VARCHAR(30)   NOT NULL DEFAULT 'planning'
      CHECK (status IN ('planning','active','on_hold','completed','cancelled')),
   priority          SMALLINT      NOT NULL DEFAULT 3
      CHECK (priority BETWEEN 1 AND 5),      -- 1 = highest priority
   start_date        DATE,
   end_date          DATE,
   budget            NUMERIC(14,2),
   created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   CONSTRAINT chk_project_dates CHECK (end_date IS NULL OR end_date >= start_date)
);

COMMENT ON TABLE  :"schema_name".:"tbl_projects"
   IS 'Projects belong to one organisation and have a designated owner.';
COMMENT ON COLUMN :"schema_name".:"tbl_projects".priority
   IS '1 = critical, 5 = low priority.';

-- ----------------------------------------------------------------------------
-- 6.4  milestones
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_milestones" (
   milestone_id   UUID         DEFAULT uuid_generate_v4() PRIMARY KEY,
   project_id     UUID         NOT NULL
      REFERENCES :"schema_name".:"tbl_projects"(project_id) ON DELETE CASCADE,
   name           VARCHAR(200) NOT NULL,
   due_date       DATE         NOT NULL,
   is_completed   BOOLEAN      NOT NULL DEFAULT FALSE,
   completed_at   TIMESTAMPTZ,
   created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE :"schema_name".:"tbl_milestones"
   IS 'Key delivery gates within a project.';

-- ----------------------------------------------------------------------------
-- 6.5  tasks
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_tasks" (
   task_id         UUID          DEFAULT uuid_generate_v4() PRIMARY KEY,
   project_id      UUID          NOT NULL
      REFERENCES :"schema_name".:"tbl_projects"(project_id)   ON DELETE CASCADE,
   milestone_id    UUID
      REFERENCES :"schema_name".:"tbl_milestones"(milestone_id) ON DELETE SET NULL,
   assignee_id     UUID
      REFERENCES :"schema_name".:"tbl_users"(user_id)          ON DELETE SET NULL,
   created_by_id   UUID          NOT NULL
      REFERENCES :"schema_name".:"tbl_users"(user_id),
   title           VARCHAR(300)  NOT NULL,
   description     TEXT,
   status          VARCHAR(30)   NOT NULL DEFAULT 'backlog'
      CHECK (status IN ('backlog','in_progress','in_review','done','cancelled')),
   priority        SMALLINT      NOT NULL DEFAULT 3
      CHECK (priority BETWEEN 1 AND 5),
   story_points    SMALLINT      CHECK (story_points > 0),
   due_date        DATE,
   completed_at    TIMESTAMPTZ,
   created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
   updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE :"schema_name".:"tbl_tasks"
   IS 'Atomic work items, optionally linked to a milestone.';

-- ----------------------------------------------------------------------------
-- 6.6  task_comments
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_task_comments" (
   comment_id   UUID        DEFAULT uuid_generate_v4() PRIMARY KEY,
   task_id      UUID        NOT NULL
      REFERENCES :"schema_name".:"tbl_tasks"(task_id)  ON DELETE CASCADE,
   author_id    UUID        NOT NULL
      REFERENCES :"schema_name".:"tbl_users"(user_id),
   body         TEXT        NOT NULL,
   created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
   updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6.7  tags  +  task_tags  (many-to-many join table)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_tags" (
   tag_id   UUID        DEFAULT uuid_generate_v4() PRIMARY KEY,
   name     VARCHAR(60) NOT NULL UNIQUE,
   colour   CHAR(7)     DEFAULT '#607D8B'   -- hex colour for UI badges
);

CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_task_tags" (
   task_id  UUID NOT NULL REFERENCES :"schema_name".:"tbl_tasks"(task_id) ON DELETE CASCADE,
   tag_id   UUID NOT NULL REFERENCES :"schema_name".:"tbl_tags"(tag_id)   ON DELETE CASCADE,
   PRIMARY KEY (task_id, tag_id)
);

-- ----------------------------------------------------------------------------
-- 6.8  audit_log  (append-only change history)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS :"schema_name".:"tbl_audit_log" (
   log_id      BIGSERIAL    PRIMARY KEY,
   table_name  VARCHAR(100) NOT NULL,
   record_id   UUID         NOT NULL,
   action      CHAR(1)      NOT NULL CHECK (action IN ('I','U','D')),
   changed_by  UUID,
   changed_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
   old_data    JSONB,
   new_data    JSONB
);

COMMENT ON TABLE  :"schema_name".:"tbl_audit_log"
   IS 'Immutable audit trail for key table mutations.';
COMMENT ON COLUMN :"schema_name".:"tbl_audit_log".action
   IS 'I = INSERT, U = UPDATE, D = DELETE.';


-- =============================================================================
-- SECTION 7: INDEXES
-- =============================================================================

\echo '>> [7/10] Creating indexes'

-- users
CREATE INDEX IF NOT EXISTS idx_users_org
   ON :"schema_name".:"tbl_users"(organisation_id);
CREATE INDEX IF NOT EXISTS idx_users_email_trgm
   ON :"schema_name".:"tbl_users" USING gin(email gin_trgm_ops);

-- projects
CREATE INDEX IF NOT EXISTS idx_projects_org
   ON :"schema_name".:"tbl_projects"(organisation_id);
CREATE INDEX IF NOT EXISTS idx_projects_owner
   ON :"schema_name".:"tbl_projects"(owner_id);
CREATE INDEX IF NOT EXISTS idx_projects_status
   ON :"schema_name".:"tbl_projects"(status);

-- tasks
CREATE INDEX IF NOT EXISTS idx_tasks_project
   ON :"schema_name".:"tbl_tasks"(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee
   ON :"schema_name".:"tbl_tasks"(assignee_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status
   ON :"schema_name".:"tbl_tasks"(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date
   ON :"schema_name".:"tbl_tasks"(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_title_trgm
   ON :"schema_name".:"tbl_tasks" USING gin(title gin_trgm_ops);

-- audit_log
CREATE INDEX IF NOT EXISTS idx_audit_table_record
   ON :"schema_name".:"tbl_audit_log"(table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_audit_changed_at
   ON :"schema_name".:"tbl_audit_log"(changed_at DESC);


-- =============================================================================
-- SECTION 8: TRIGGER — auto-update updated_at
-- =============================================================================

\echo '>> [8/10] Creating trigger function and applying to tables'

-- Create or replace the trigger function under the configured schema
CREATE OR REPLACE FUNCTION :"schema_name".:"fn_updated_at"()
RETURNS TRIGGER
LANGUAGE plpgsql AS
$$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$;

-- Apply idempotently to every table that has an updated_at column
DO
$$
DECLARE
   tbl TEXT;
BEGIN
   FOREACH tbl IN ARRAY ARRAY[
      :'tbl_users',
      :'tbl_projects',
      :'tbl_tasks',
      :'tbl_task_comments'
   ]
   LOOP
      EXECUTE format(
         'DROP TRIGGER IF EXISTS trg_set_updated_at ON %I.%I;
          CREATE TRIGGER trg_set_updated_at
            BEFORE UPDATE ON %I.%I
            FOR EACH ROW EXECUTE FUNCTION %I.%I();',
         :'schema_name', tbl,
         :'schema_name', tbl,
         :'schema_name', :'fn_updated_at'
      );
      RAISE NOTICE 'Trigger applied to %.%', :'schema_name', tbl;
   END LOOP;
END;
$$;


-- =============================================================================
-- SECTION 9: SEED DATA  (idempotent — INSERT … ON CONFLICT DO NOTHING)
-- =============================================================================

\echo '>> [9/10] Seeding data'

-- ── 9.1  organisations ───────────────────────────────────────────────────────
INSERT INTO :"schema_name".:"tbl_organisations"
   (organisation_id, name, industry, country)
VALUES
   ('a1000000-0000-0000-0000-000000000001', 'Nexus Defence Consulting', 'Defence',          'AU'),
   ('a1000000-0000-0000-0000-000000000002', 'SkyBridge Technologies',   'Information Tech', 'AU'),
   ('a1000000-0000-0000-0000-000000000003', 'HealthCore Systems',       'Healthcare',       'AU')
ON CONFLICT (organisation_id) DO NOTHING;

-- ── 9.2  users ───────────────────────────────────────────────────────────────
-- NOTE: password_hash values are bcrypt placeholders — replace before production.
INSERT INTO :"schema_name".:"tbl_users"
   (user_id, organisation_id, email, full_name, role, password_hash)
VALUES
   ('b1000000-0000-0000-0000-000000000001',
    'a1000000-0000-0000-0000-000000000001',
    'alice.chen@nexusdefence.com.au',  'Alice Chen',       'admin',
    '$2b$12$PLACEHOLDER_HASH_ADMIN_ALICE'),

   ('b1000000-0000-0000-0000-000000000002',
    'a1000000-0000-0000-0000-000000000001',
    'bob.nguyen@nexusdefence.com.au',  'Bob Nguyen',       'manager',
    '$2b$12$PLACEHOLDER_HASH_MGR_BOB'),

   ('b1000000-0000-0000-0000-000000000003',
    'a1000000-0000-0000-0000-000000000001',
    'sara.smith@nexusdefence.com.au',  'Sara Smith',       'tester',
    '$2b$12$PLACEHOLDER_HASH_TESTER_SARA'),

   ('b1000000-0000-0000-0000-000000000004',
    'a1000000-0000-0000-0000-000000000002',
    'james.ward@skybridge.com.au',     'James Ward',       'developer',
    '$2b$12$PLACEHOLDER_HASH_DEV_JAMES'),

   ('b1000000-0000-0000-0000-000000000005',
    'a1000000-0000-0000-0000-000000000002',
    'priya.ram@skybridge.com.au',      'Priya Ramanujan',  'manager',
    '$2b$12$PLACEHOLDER_HASH_MGR_PRIYA')
ON CONFLICT (user_id) DO NOTHING;

-- ── 9.3  projects ────────────────────────────────────────────────────────────
INSERT INTO :"schema_name".:"tbl_projects"
   (project_id, organisation_id, owner_id, name, description,
    status, priority, start_date, end_date, budget)
VALUES
   ('c1000000-0000-0000-0000-000000000001',
    'a1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000002',
    'COSPO OT&E Automation Suite',
    'Operational Test and Evaluation framework for COSPO CYB9131 programme.',
    'active', 1, '2025-01-15', '2025-12-31', 480000.00),

   ('c1000000-0000-0000-0000-000000000002',
    'a1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000002',
    'One Defence Data — Tranche 2',
    'Continuation of 1DD data migration and integration testing for Tranche 2.',
    'planning', 2, '2025-07-01', '2026-06-30', 920000.00),

   ('c1000000-0000-0000-0000-000000000003',
    'a1000000-0000-0000-0000-000000000002',
    'b1000000-0000-0000-0000-000000000005',
    'Cloud Infrastructure Migration',
    'Lift-and-shift of on-premises workloads to Azure with Terraform IaC.',
    'active', 2, '2025-03-01', '2025-10-31', 310000.00)
ON CONFLICT (project_id) DO NOTHING;

-- ── 9.4  milestones ──────────────────────────────────────────────────────────
INSERT INTO :"schema_name".:"tbl_milestones"
   (milestone_id, project_id, name, due_date, is_completed)
VALUES
   ('d1000000-0000-0000-0000-000000000001',
    'c1000000-0000-0000-0000-000000000001',
    'Test Environment Provisioned', '2025-03-31', TRUE),

   ('d1000000-0000-0000-0000-000000000002',
    'c1000000-0000-0000-0000-000000000001',
    'VCRM v1.0 Baselined',          '2025-06-30', FALSE),

   ('d1000000-0000-0000-0000-000000000003',
    'c1000000-0000-0000-0000-000000000003',
    'Azure Landing Zone Deployed',  '2025-05-31', FALSE)
ON CONFLICT (milestone_id) DO NOTHING;

-- ── 9.5  tasks ───────────────────────────────────────────────────────────────
INSERT INTO :"schema_name".:"tbl_tasks"
   (task_id, project_id, milestone_id, assignee_id, created_by_id,
    title, description, status, priority, story_points, due_date)
VALUES
   ('e1000000-0000-0000-0000-000000000001',
    'c1000000-0000-0000-0000-000000000001',
    'd1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000002',
    'Draft Test and Evaluation Master Plan (TEMP)',
    'Produce initial TEMP covering scope, objectives, resources, and schedule.',
    'in_progress', 1, 13, '2025-04-30'),

   ('e1000000-0000-0000-0000-000000000002',
    'c1000000-0000-0000-0000-000000000001',
    'd1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000002',
    'Configure Azure DevOps CI/CD Pipeline for Test Automation',
    'Set up pipelines using YAML templates; integrate Selenium WebDriver suite.',
    'backlog', 2, 8, '2025-05-15'),

   ('e1000000-0000-0000-0000-000000000003',
    'c1000000-0000-0000-0000-000000000001',
    'd1000000-0000-0000-0000-000000000002',
    'b1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000002',
    'Build Verification Cross Reference Matrix (VCRM)',
    'Map system requirements to test cases; baseline for AT&E phase.',
    'backlog', 1, 21, '2025-06-15'),

   ('e1000000-0000-0000-0000-000000000004',
    'c1000000-0000-0000-0000-000000000003',
    'd1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000004',
    'b1000000-0000-0000-0000-000000000005',
    'Author Terraform Modules for Azure Landing Zone',
    'Modules for VNet, NSG, Key Vault, Storage Account with Terraform 1.7.',
    'in_progress', 2, 13, '2025-05-10'),

   ('e1000000-0000-0000-0000-000000000005',
    'c1000000-0000-0000-0000-000000000003',
    'd1000000-0000-0000-0000-000000000003',
    'b1000000-0000-0000-0000-000000000004',
    'b1000000-0000-0000-0000-000000000005',
    'Implement Ansible Playbooks for OS Hardening',
    'CIS Level 2 baseline applied via Ansible roles on all Azure VMs.',
    'backlog', 2, 8, '2025-05-25')
ON CONFLICT (task_id) DO NOTHING;

-- ── 9.6  tags ────────────────────────────────────────────────────────────────
INSERT INTO :"schema_name".:"tbl_tags" (tag_id, name, colour) VALUES
   ('f1000000-0000-0000-0000-000000000001', 'security',      '#F44336'),
   ('f1000000-0000-0000-0000-000000000002', 'automation',    '#2196F3'),
   ('f1000000-0000-0000-0000-000000000003', 'documentation', '#FF9800'),
   ('f1000000-0000-0000-0000-000000000004', 'infrastructure','#4CAF50'),
   ('f1000000-0000-0000-0000-000000000005', 'testing',       '#9C27B0')
ON CONFLICT (tag_id) DO NOTHING;

-- ── 9.7  task_tags (join table) ──────────────────────────────────────────────
INSERT INTO :"schema_name".:"tbl_task_tags" (task_id, tag_id) VALUES
   ('e1000000-0000-0000-0000-000000000001','f1000000-0000-0000-0000-000000000003'), -- TEMP       → documentation
   ('e1000000-0000-0000-0000-000000000001','f1000000-0000-0000-0000-000000000005'), -- TEMP       → testing
   ('e1000000-0000-0000-0000-000000000002','f1000000-0000-0000-0000-000000000002'), -- CI/CD      → automation
   ('e1000000-0000-0000-0000-000000000002','f1000000-0000-0000-0000-000000000005'), -- CI/CD      → testing
   ('e1000000-0000-0000-0000-000000000003','f1000000-0000-0000-0000-000000000003'), -- VCRM       → documentation
   ('e1000000-0000-0000-0000-000000000003','f1000000-0000-0000-0000-000000000005'), -- VCRM       → testing
   ('e1000000-0000-0000-0000-000000000004','f1000000-0000-0000-0000-000000000004'), -- Terraform  → infrastructure
   ('e1000000-0000-0000-0000-000000000005','f1000000-0000-0000-0000-000000000001'), -- Ansible    → security
   ('e1000000-0000-0000-0000-000000000005','f1000000-0000-0000-0000-000000000004')  -- Ansible    → infrastructure
ON CONFLICT DO NOTHING;

-- ── 9.8  task_comments ───────────────────────────────────────────────────────
INSERT INTO :"schema_name".:"tbl_task_comments" (task_id, author_id, body) VALUES
   ('e1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000002',
    'Prioritise Section 4 (Test Resources) first — resource confirmation is on the critical path.'),

   ('e1000000-0000-0000-0000-000000000001',
    'b1000000-0000-0000-0000-000000000003',
    'Initial draft ready for review. Shared in SharePoint under /COSPO/TEMP/v0.1.'),

   ('e1000000-0000-0000-0000-000000000004',
    'b1000000-0000-0000-0000-000000000004',
    'Hub-spoke topology confirmed with network team. First module PR ready by Friday.')
ON CONFLICT DO NOTHING;


-- =============================================================================
-- SECTION 10: VERIFICATION QUERIES
-- =============================================================================

\echo '>> [10/10] Running verification queries'

-- Row counts per table
SELECT 'organisations' AS table_name, COUNT(*) AS rows FROM :"schema_name".:"tbl_organisations"
UNION ALL SELECT 'users',         COUNT(*) FROM :"schema_name".:"tbl_users"
UNION ALL SELECT 'projects',      COUNT(*) FROM :"schema_name".:"tbl_projects"
UNION ALL SELECT 'milestones',    COUNT(*) FROM :"schema_name".:"tbl_milestones"
UNION ALL SELECT 'tasks',         COUNT(*) FROM :"schema_name".:"tbl_tasks"
UNION ALL SELECT 'tags',          COUNT(*) FROM :"schema_name".:"tbl_tags"
UNION ALL SELECT 'task_tags',     COUNT(*) FROM :"schema_name".:"tbl_task_tags"
UNION ALL SELECT 'task_comments', COUNT(*) FROM :"schema_name".:"tbl_task_comments"
ORDER BY table_name;

-- Active tasks with project, assignee, and tags
SELECT
   p.name                     AS project,
   t.title                    AS task,
   t.status,
   t.priority,
   u.full_name                AS assignee,
   t.due_date,
   STRING_AGG(tg.name, ', ') AS tags
FROM       :"schema_name".:"tbl_tasks"       t
JOIN       :"schema_name".:"tbl_projects"    p  ON p.project_id = t.project_id
LEFT JOIN  :"schema_name".:"tbl_users"       u  ON u.user_id    = t.assignee_id
LEFT JOIN  :"schema_name".:"tbl_task_tags"   tt ON tt.task_id   = t.task_id
LEFT JOIN  :"schema_name".:"tbl_tags"        tg ON tg.tag_id    = tt.tag_id
WHERE t.status NOT IN ('done','cancelled')
GROUP BY p.name, t.title, t.status, t.priority, u.full_name, t.due_date
ORDER BY t.priority, t.due_date;

\echo '>> Setup complete.'

-- =============================================================================
-- END OF SCRIPT
-- =============================================================================
