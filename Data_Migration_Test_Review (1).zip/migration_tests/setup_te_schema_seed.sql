-- Setup + seed for Defence T&E test suites
-- Usage:
--   psql -U postgres -d <db> -v schema_name=<schema> -f setup_te_schema_seed.sql

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE SCHEMA IF NOT EXISTS :"schema_name";
SET search_path TO :"schema_name", public;

-- Drop in dependency order for repeatable runs
DROP TABLE IF EXISTS :"schema_name".evidence_artifacts CASCADE;
DROP TABLE IF EXISTS :"schema_name".defect_reports CASCADE;
DROP TABLE IF EXISTS :"schema_name".test_run_results CASCADE;
DROP TABLE IF EXISTS :"schema_name".test_results CASCADE;
DROP TABLE IF EXISTS :"schema_name".test_events CASCADE;
DROP TABLE IF EXISTS :"schema_name".vcrm_entries CASCADE;
DROP TABLE IF EXISTS :"schema_name".test_cases CASCADE;
DROP TABLE IF EXISTS :"schema_name".requirements CASCADE;
DROP TABLE IF EXISTS :"schema_name".test_phases CASCADE;
DROP TABLE IF EXISTS :"schema_name".temp_documents CASCADE;
DROP TABLE IF EXISTS :"schema_name".test_programs CASCADE;
DROP TABLE IF EXISTS :"schema_name".personnel CASCADE;
DROP TABLE IF EXISTS :"schema_name".organisations CASCADE;

CREATE TABLE :"schema_name".organisations (
  org_id UUID PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  org_type TEXT NOT NULL CHECK (org_type IN ('government','prime','subcontractor','test_unit','academic')),
  country CHAR(2) NOT NULL DEFAULT 'AU',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE :"schema_name".personnel (
  person_id UUID PRIMARY KEY,
  org_id UUID NOT NULL REFERENCES :"schema_name".organisations(org_id),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  te_role TEXT NOT NULL CHECK (te_role IN ('test_director','test_manager','test_engineer','te_analyst','safety_engineer','config_manager','observer')),
  clearance TEXT NOT NULL CHECK (clearance IN ('baseline','NV1','NV2','PV')),
  password_hash TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE :"schema_name".test_programs (
  program_id UUID PRIMARY KEY,
  org_id UUID NOT NULL REFERENCES :"schema_name".organisations(org_id),
  program_code TEXT NOT NULL UNIQUE,
  program_name TEXT NOT NULL,
  classification TEXT NOT NULL CHECK (classification IN ('UNCLASSIFIED','PROTECTED','SECRET','TOP SECRET')),
  status TEXT NOT NULL CHECK (status IN ('planning','active','suspended','completed','cancelled')),
  start_date DATE,
  end_date DATE,
  program_director_id UUID REFERENCES :"schema_name".personnel(person_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_program_dates CHECK (end_date IS NULL OR end_date >= start_date)
);

CREATE TABLE :"schema_name".temp_documents (
  temp_id UUID PRIMARY KEY,
  program_id UUID NOT NULL REFERENCES :"schema_name".test_programs(program_id),
  version TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft','in_review','approved','superseded','cancelled')),
  author_id UUID NOT NULL REFERENCES :"schema_name".personnel(person_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (program_id, version)
);

CREATE TABLE :"schema_name".test_phases (
  phase_id UUID PRIMARY KEY,
  program_id UUID NOT NULL REFERENCES :"schema_name".test_programs(program_id),
  phase_code TEXT NOT NULL,
  phase_type TEXT NOT NULL CHECK (phase_type IN ('DT&E','AT&E','OT&E','IOT&E','LFT&E','FOLLOW_ON')),
  status TEXT NOT NULL CHECK (status IN ('planned','in_progress','completed','cancelled')),
  actual_start DATE,
  planned_start DATE,
  planned_end DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (program_id, phase_code)
);

CREATE TABLE :"schema_name".requirements (
  req_id UUID PRIMARY KEY,
  program_id UUID NOT NULL REFERENCES :"schema_name".test_programs(program_id),
  req_identifier TEXT NOT NULL,
  title TEXT NOT NULL,
  priority INTEGER NOT NULL CHECK (priority BETWEEN 1 AND 3),
  verification_method TEXT NOT NULL CHECK (verification_method IN ('test','analysis','inspection','demonstration')),
  req_type TEXT NOT NULL CHECK (req_type IN ('functional','performance','security','safety','interface','compliance')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (program_id, req_identifier)
);

CREATE TABLE :"schema_name".test_cases (
  tc_id UUID PRIMARY KEY,
  phase_id UUID NOT NULL REFERENCES :"schema_name".test_phases(phase_id),
  tc_identifier TEXT NOT NULL,
  title TEXT NOT NULL,
  objective TEXT NOT NULL,
  tc_type TEXT NOT NULL CHECK (tc_type IN ('functional','performance','security','regression','integration','acceptance')),
  status TEXT NOT NULL,
  author_id UUID NOT NULL REFERENCES :"schema_name".personnel(person_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (phase_id, tc_identifier)
);

CREATE TABLE :"schema_name".vcrm_entries (
  vcrm_id UUID PRIMARY KEY,
  req_id UUID NOT NULL REFERENCES :"schema_name".requirements(req_id),
  tc_id UUID NOT NULL REFERENCES :"schema_name".test_cases(tc_id),
  coverage_type TEXT NOT NULL CHECK (coverage_type IN ('full','partial','conditional')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (req_id, tc_id)
);

CREATE TABLE :"schema_name".test_events (
  event_id UUID PRIMARY KEY,
  phase_id UUID NOT NULL REFERENCES :"schema_name".test_phases(phase_id),
  event_code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL CHECK (status IN ('planned','in_progress','completed','cancelled')),
  planned_start DATE,
  planned_end DATE,
  actual_start DATE,
  actual_end DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE :"schema_name".test_results (
  result_id UUID PRIMARY KEY,
  event_id UUID NOT NULL REFERENCES :"schema_name".test_events(event_id),
  tc_id UUID NOT NULL REFERENCES :"schema_name".test_cases(tc_id),
  verdict TEXT NOT NULL CHECK (verdict IN ('pass','fail','blocked','not_run','inconclusive')),
  actual_result TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE :"schema_name".defect_reports (
  defect_id UUID PRIMARY KEY,
  defect_ref TEXT NOT NULL UNIQUE,
  result_id UUID REFERENCES :"schema_name".test_results(result_id),
  program_id UUID NOT NULL REFERENCES :"schema_name".test_programs(program_id),
  raised_by_id UUID NOT NULL REFERENCES :"schema_name".personnel(person_id),
  severity TEXT NOT NULL CHECK (severity IN ('critical','major','minor','observation')),
  status TEXT NOT NULL CHECK (status IN ('open','in_progress','resolved','closed')),
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE :"schema_name".evidence_artifacts (
  artifact_id UUID PRIMARY KEY,
  result_id UUID REFERENCES :"schema_name".test_results(result_id),
  file_path TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Required indexes asserted by suite 05
CREATE INDEX idx_personnel_org ON :"schema_name".personnel(org_id);
CREATE INDEX idx_programs_status ON :"schema_name".test_programs(status);
CREATE INDEX idx_testcases_phase ON :"schema_name".test_cases(phase_id);
CREATE INDEX idx_results_verdict ON :"schema_name".test_results(verdict);
CREATE INDEX idx_defects_severity ON :"schema_name".defect_reports(severity);
CREATE INDEX idx_vcrm_req ON :"schema_name".vcrm_entries(req_id);
CREATE INDEX idx_personnel_email_trgm ON :"schema_name".personnel USING gin (email gin_trgm_ops);

CREATE OR REPLACE FUNCTION :"schema_name".set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END $$;

CREATE TRIGGER trg_updated_at BEFORE UPDATE ON :"schema_name".organisations FOR EACH ROW EXECUTE FUNCTION :"schema_name".set_updated_at();
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON :"schema_name".personnel FOR EACH ROW EXECUTE FUNCTION :"schema_name".set_updated_at();
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON :"schema_name".test_programs FOR EACH ROW EXECUTE FUNCTION :"schema_name".set_updated_at();
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON :"schema_name".defect_reports FOR EACH ROW EXECUTE FUNCTION :"schema_name".set_updated_at();

-- Seed data
INSERT INTO :"schema_name".organisations (org_id,name,org_type,country) VALUES
 ('00000000-0000-0000-0000-000000000001','Capability Acquisition and Sustainment Group','government','AU'),
 ('00000000-0000-0000-0000-000000000002','Leidos Australia','prime','AU'),
 ('00000000-0000-0000-0000-000000000003','KBR Defence Services','subcontractor','AU'),
 ('00000000-0000-0000-0000-000000000004','Joint Test Unit Alpha','test_unit','AU'),
 ('00000000-0000-0000-0000-000000000005','UNSW Canberra','academic','AU');

INSERT INTO :"schema_name".personnel (person_id,org_id,full_name,email,te_role,clearance,password_hash) VALUES
 ('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','Ava Director','ava.director@defence.gov.au','test_director','PV','$2b$12$aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
 ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000002','Noah Manager','noah.manager@leidos.com.au','test_manager','NV2','$2b$12$bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'),
 ('10000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000002','Mia Engineer','mia.engineer@leidos.com.au','test_engineer','NV1','$2b$12$ccccccccccccccccccccccccccccccccccccccccccccccccccccc'),
 ('10000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000003','Liam Analyst','liam.analyst@kbr.com.au','te_analyst','NV1','$2b$12$ddddddddddddddddddddddddddddddddddddddddddddddddddddd'),
 ('10000000-0000-0000-0000-000000000005','00000000-0000-0000-0000-000000000004','Olivia Safety','olivia.safety@jtu.mil.au','safety_engineer','NV2','$2b$12$eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee'),
 ('10000000-0000-0000-0000-000000000006','00000000-0000-0000-0000-000000000005','Ethan Config','ethan.config@unsw.edu.au','config_manager','NV1','$2b$12$fffffffffffffffffffffffffffffffffffffffffffffffffffff');

INSERT INTO :"schema_name".test_programs (program_id,org_id,program_code,program_name,classification,status,start_date,end_date,program_director_id) VALUES
 ('20000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','CYB9131','Cyber Capability 9131','PROTECTED','active','2025-01-01','2025-12-31','10000000-0000-0000-0000-000000000002'),
 ('20000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000002','LAND400-P3','Land 400 Phase 3','PROTECTED','planning','2025-02-01','2026-06-30','10000000-0000-0000-0000-000000000001');

INSERT INTO :"schema_name".temp_documents (temp_id,program_id,version,status,author_id) VALUES
 ('30000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','v1.0','approved','10000000-0000-0000-0000-000000000003'),
 ('30000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001','v1.1','in_review','10000000-0000-0000-0000-000000000002'),
 ('30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002','v0.1','draft','10000000-0000-0000-0000-000000000004');

INSERT INTO :"schema_name".test_phases (phase_id,program_id,phase_code,phase_type,status,actual_start,planned_start,planned_end) VALUES
 ('40000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','CYB9131-DTE','DT&E','completed','2025-02-01','2025-02-01','2025-03-15'),
 ('40000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001','CYB9131-OTE','OT&E','in_progress','2025-04-01','2025-04-01','2025-06-30'),
 ('40000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002','LAND400-IOTE','IOT&E','planned',NULL,'2025-08-01','2025-09-15');

INSERT INTO :"schema_name".requirements (req_id,program_id,req_identifier,title,priority,verification_method,req_type) VALUES
 ('50000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','SYS-SEC-001','MFA Enforcement',1,'test','security'),
 ('50000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001','SYS-PERF-001','Availability SLA',1,'analysis','performance'),
 ('50000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000001','SYS-FUNC-001','User login workflow',2,'test','functional'),
 ('50000000-0000-0000-0000-000000000004','20000000-0000-0000-0000-000000000001','SYS-INT-001','SIEM integration',2,'inspection','interface'),
 ('50000000-0000-0000-0000-000000000005','20000000-0000-0000-0000-000000000001','SYS-SAFE-001','Audit retention controls',3,'demonstration','safety'),
 ('50000000-0000-0000-0000-000000000006','20000000-0000-0000-0000-000000000001','SYS-COMP-001','ISM compliance evidence',1,'test','compliance'),
 ('50000000-0000-0000-0000-000000000007','20000000-0000-0000-0000-000000000002','LAND-FUNC-001','Vehicle telemetry ingest',2,'test','functional'),
 ('50000000-0000-0000-0000-000000000008','20000000-0000-0000-0000-000000000002','LAND-SEC-001','Radio hardening baseline',1,'analysis','security');

INSERT INTO :"schema_name".test_cases (tc_id,phase_id,tc_identifier,title,objective,tc_type,status,author_id) VALUES
 ('60000000-0000-0000-0000-000000000001','40000000-0000-0000-0000-000000000002','TC-OTE-001','MFA valid TOTP','Verify valid OTP authentication','security','approved','10000000-0000-0000-0000-000000000003'),
 ('60000000-0000-0000-0000-000000000002','40000000-0000-0000-0000-000000000002','TC-OTE-002','MFA invalid TOTP','Verify lockout after invalid OTP','security','approved','10000000-0000-0000-0000-000000000003'),
 ('60000000-0000-0000-0000-000000000003','40000000-0000-0000-0000-000000000002','TC-OTE-003','Availability soak','Validate 72-hour availability','performance','approved','10000000-0000-0000-0000-000000000002'),
 ('60000000-0000-0000-0000-000000000004','40000000-0000-0000-0000-000000000002','TC-OTE-004','Session timeout','Validate auto timeout','functional','approved','10000000-0000-0000-0000-000000000004'),
 ('60000000-0000-0000-0000-000000000005','40000000-0000-0000-0000-000000000002','TC-OTE-005','SIEM event forwarding','Validate event forward path','integration','approved','10000000-0000-0000-0000-000000000004'),
 ('60000000-0000-0000-0000-000000000006','40000000-0000-0000-0000-000000000002','TC-OTE-006','Audit retention export','Verify retention and retrieval','regression','approved','10000000-0000-0000-0000-000000000005'),
 ('60000000-0000-0000-0000-000000000007','40000000-0000-0000-0000-000000000002','TC-OTE-007','Compliance report','Validate compliance evidence report','acceptance','approved','10000000-0000-0000-0000-000000000006'),
 ('60000000-0000-0000-0000-000000000008','40000000-0000-0000-0000-000000000002','TC-OTE-008','API login regression','Verify login API regression paths','functional','approved','10000000-0000-0000-0000-000000000003');

INSERT INTO :"schema_name".vcrm_entries (vcrm_id,req_id,tc_id,coverage_type) VALUES
 ('70000000-0000-0000-0000-000000000001','50000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000001','full'),
 ('70000000-0000-0000-0000-000000000002','50000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000002','full'),
 ('70000000-0000-0000-0000-000000000003','50000000-0000-0000-0000-000000000002','60000000-0000-0000-0000-000000000003','full'),
 ('70000000-0000-0000-0000-000000000004','50000000-0000-0000-0000-000000000003','60000000-0000-0000-0000-000000000004','full'),
 ('70000000-0000-0000-0000-000000000005','50000000-0000-0000-0000-000000000004','60000000-0000-0000-0000-000000000005','partial'),
 ('70000000-0000-0000-0000-000000000006','50000000-0000-0000-0000-000000000005','60000000-0000-0000-0000-000000000006','conditional'),
 ('70000000-0000-0000-0000-000000000007','50000000-0000-0000-0000-000000000006','60000000-0000-0000-0000-000000000007','full'),
 ('70000000-0000-0000-0000-000000000008','50000000-0000-0000-0000-000000000006','60000000-0000-0000-0000-000000000008','partial');

INSERT INTO :"schema_name".test_events (event_id,phase_id,event_code,status,planned_start,planned_end,actual_start,actual_end) VALUES
 ('80000000-0000-0000-0000-000000000001','40000000-0000-0000-0000-000000000002','CYB9131-OTE-EV01','completed','2025-04-10','2025-04-12','2025-04-10','2025-04-12'),
 ('80000000-0000-0000-0000-000000000002','40000000-0000-0000-0000-000000000002','CYB9131-OTE-EV02','in_progress','2025-04-20','2025-04-23','2025-04-20',NULL),
 ('80000000-0000-0000-0000-000000000003','40000000-0000-0000-0000-000000000002','CYB9131-OTE-EV03','planned','2025-05-01','2025-05-03',NULL,NULL);

INSERT INTO :"schema_name".test_results (result_id,event_id,tc_id,verdict,actual_result,notes) VALUES
 ('90000000-0000-0000-0000-000000000001','80000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000001','pass','MFA accepted valid OTP',NULL),
 ('90000000-0000-0000-0000-000000000002','80000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000002','fail','Lockout threshold not enforced',NULL),
 ('90000000-0000-0000-0000-000000000003','80000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000004','pass','Session policy applied',NULL),
 ('90000000-0000-0000-0000-000000000004','80000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000005','pass','SIEM events visible',NULL),
 ('90000000-0000-0000-0000-000000000005','80000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000006','fail','Retention export missing metadata',NULL),
 ('90000000-0000-0000-0000-000000000006','80000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000007','pass','Report generated',NULL),
 ('90000000-0000-0000-0000-000000000007','80000000-0000-0000-0000-000000000002','60000000-0000-0000-0000-000000000003','inconclusive',NULL,'72-hour run still active');

INSERT INTO :"schema_name".defect_reports (defect_id,defect_ref,result_id,program_id,raised_by_id,severity,status) VALUES
 ('a0000000-0000-0000-0000-000000000001','DR-CYB-0001','90000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000003','major','open'),
 ('a0000000-0000-0000-0000-000000000002','DR-CYB-0002','90000000-0000-0000-0000-000000000005','20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000004','major','in_progress'),
 ('a0000000-0000-0000-0000-000000000003','DR-CYB-0003','90000000-0000-0000-0000-000000000007','20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000005','minor','open');

-- evidence_artifacts intentionally left empty
